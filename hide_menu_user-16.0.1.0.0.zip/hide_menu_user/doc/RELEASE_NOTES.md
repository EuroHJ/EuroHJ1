## Module <hide_menu_user>

#### 30.12.2021
#### Version 15.0.1.0.0
#### ADD
- Initial commit for hide_menu_user



