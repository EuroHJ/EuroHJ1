## Module <inventory_stock_dashboard_odoo>

#### 24.05.2022
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Inventory Dashboard Module

#### 24.07.2023
#### Version 16.0.1.0.1
##### FIX
- The font size reduction problem when installing this module has been fixed.
