# -*- coding: utf-8 -*-
##############################################################################
#    
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Devintelle Solutions (<http://devintellecs.com/>).
#
##############################################################################

from . import bulk_cancel_picking
from . import bulk_set_to_draft

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
