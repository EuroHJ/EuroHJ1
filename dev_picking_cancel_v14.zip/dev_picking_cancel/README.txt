All in one Cancel Sale,Purchase,Picking:
=========================================================

Go to Setting / App and search "All in one Cancel Sale,Purchase,Picking" and Install

And, you are done with installation. Congratulations!
