=================================
V16 Restriction on Product Creation
=================================
This odoo application is help  to  put restriction on product creation.
